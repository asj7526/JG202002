import java.util.Scanner;
import java.util.Random;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Random rand= new Random(100);
		
		Scanner sc = new Scanner(System.in);
		
		
		
		System.out.println("�������� ����(N): ");
		int n = sc.nextInt();
		
		
		int [] res = new int[n];
		for(int i=0;i<n;i++){
			res[i]=rand.nextInt(n)+1;
			for(int q=0;q<i;q++){
				if(res[i]==res[q]){
					i--;
				    break;
				}
			}
		}
		for(int i=0;i<n;i++){
			System.out.println(res[i]);
		}
		int a=0;
		int b=0;
		
		System.out.println("��������(K): ");
		int k=sc.nextInt();
		
		
		for(int i=0;i<k;i++){
			 int sum=0;
			 a=rand.nextInt(n)+1;
			 b=rand.nextInt(n)+1;
			System.out.println("����"+a+" "+b);
			
			int max=res[a-1];
			int min=res[a-1];
			if(a<=b){
				for(int m=a-1;m<b;m++){
					
					if(min>res[m]){
						min=res[m];
					}
				}
			}
			else if(a>b){
				for(int m=b-1;m<a;m++){
					if(min>res[m]){
						min=res[m];
					}
				}
			}
			
			System.out.println("���� �� �ּ� ��: "+ min);
			
			
			
			if (a<=b){
				for(int j=a-1;j<b;j++){
					
					if(max<res[j]){
						max=res[j];
					}
				}
			}
			else if(a>b){
				for(int j=b-1;j<a;j++){
					if(max<res[j]){
						max=res[j];
					}
				}
			}
			System.out.println("���� �� �ִ� ��: " + max);
			
			if(a<b){
				for(int p=a-1;p<b;p++){
					sum+=res[p];
				}
			}
			else if(a>b){
				for(int p=b-1;p<a;p++){
					sum+=res[p];
				}
			}
			else if(a==b){
				sum=res[a-1];
			}
			System.out.println("���� �� �հ�: " + sum);
			System.out.println(" ");
			}
	
		
		}

}
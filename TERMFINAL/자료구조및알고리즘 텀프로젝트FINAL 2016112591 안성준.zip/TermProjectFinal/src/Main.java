import java.util.Random;
import java.util.Scanner;


public class Main{


public static int[] findMinMax(int[] a,int i,int j) {
    int min,max;
    int mid,leftmin,leftmax,rightmin,rightmax;
    int[] result = new int[2];

    
    if (i==j) {
        min = a[i];               
        max = a[i];
    }
    else {
        mid = (i + j) / 2;
        int[] leftres = findMinMax(a, i, mid);           //��������
        int[] rightres = findMinMax(a, mid+1, j);
        leftmin = leftres[0];
        leftmax = leftres[1];
        rightmin=rightres[0];
        rightmax=rightres[1];
        
        if (leftmin < rightmin){
        	min = leftmin;
        }
        else {
        	min=rightmin;
        }
        if (leftmax < rightmax) {
        	max = rightmax;
        }
        else {
        	max=leftmax;
        	}
    	}

    	result[0] = min;
    	result[1] = max;
    	return result;
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stubRandom r
		Random rand= new Random(100);
		Scanner sc = new Scanner(System.in);
		
		
		
		System.out.println("�������� ����(N): ");
		int n = sc.nextInt();
		int [] res = new int[n];
		for(int i=0;i<n;i++){
			res[i]=rand.nextInt()+1;
		}
		
		for(int i=0;i<n;i++){
			System.out.println(res[i]);
		}
		int a=0;
		int b=0;
		int kmin=0;
		int kmax=0;
		int [] minmax= new int[2];
		System.out.println("��������(K): ");
		int k=sc.nextInt();
		for(int i=0;i<k;i++){
			long sum=0;
			 a=rand.nextInt(n)+1;
			 b=rand.nextInt(n)+1;
			System.out.println("����"+a+" "+b);
			if(a<b){
				kmin=a-1;
				kmax=b-1;
				}
			else if(a==b){
				kmin=kmax=a-1;
;			}
			else{
				kmin=b-1;
				kmax=a-1;
			}
			minmax=findMinMax(res,kmin,kmax);
			System.out.println("�ּڰ�: "+minmax[0]);
			System.out.println("�ִ�: "+minmax[1]);
			for(int p=kmin;p<=kmax;p++){
				sum+=res[p];
			}
			System.out.println("��: "+sum);
			
			
			
		}
	

	}

}

import java.util.LinkedList;
import java.util.Queue;
import java.util.Random;
import java.util.Stack;
import java.util.Scanner;

public class Main2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Random rand = new Random();
		Scanner sc = new Scanner(System.in);
		System.out.println("���� ���� : ");
		int n=sc.nextInt();
		Queue<Integer> qu = new LinkedList<Integer>();
		Stack<Integer >st =new Stack<Integer>();
	
		
		
		
		for(int i=0; i<n; i++){
			int k=rand.nextInt(10000);
			qu.add(k);
		}
		while(!qu.isEmpty()){
			int tmp=qu.poll();
			while(!st.isEmpty()&&st.peek() < tmp){
				qu.add((Integer) st.pop());
			}
			st.push(tmp);
		}
		
		System.out.println("���� ����: ");
		
		while(!st.empty()){
			System.out.println(st.pop()+" ");
			
		}

		
		
	}

}

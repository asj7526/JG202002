import java.util.Scanner;

class Queue<E>{
		
			int front;
			int rear; 
			E[] data;
			int size;
		Queue(){ 
			front=0;
			rear=0;
			size=1000;
			data=(E[])new Object[size];
		}
		public void add(E v){
			data[rear]=v;
			rear=(rear+1)%size;
		}
		public void remove(){
			
			data[front]=null;
			
			front=(front+1)%size;
		}
		public E peek(){
			return data[front];
		}
		
		public boolean empty(){
			
			return front==rear;
		}
		public int size(){
			
			return(rear-front+size+size)%size;
			
		}
}
public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Queue<Integer> que = new Queue();
		Scanner sc= new Scanner(System.in);
		int n= sc.nextInt();
		int a=0;
		
		for(int i=0; i<n;i++){
			String k = sc.next();
			if(k.equals("push")){
				a=sc.nextInt();
				que.add(a);
			}else if(k.equals("front")){
				if(que.empty()){
					System.out.println("-1");
				}
				else{
					System.out.println(que.peek());
				}
					
			}
			else if(k.equals("back")){
				if(que.empty()){
					System.out.println("-1");
				}
				else{
					System.out.println(a);
				}
			}
			else if(k.equals("pop")){
				if(que.empty()){
					System.out.println("-1");
				}
				else{
					System.out.println(que.peek());
					que.remove();
				}
			}
			else if(k.equals("size")){
				System.out.println(que.size());
			}
			else if(k.equals("empty")){
				if(que.empty()){
					System.out.println("1");
				}
				else{
					System.out.println("0");
				}
			}
		}
		
		

	}

}

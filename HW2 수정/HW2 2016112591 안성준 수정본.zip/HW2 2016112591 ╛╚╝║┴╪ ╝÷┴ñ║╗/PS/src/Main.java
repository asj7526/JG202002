import java.util.Scanner;


public class Main {
	public static boolean isValid(String s){
		char[] stack = new char[1024];
		int top=-1;
		
		for(int i=0;i<s.length();i++){
			if(s.charAt(i)=='('){
				stack[++top]=s.charAt(i);
			}
			else if(s.charAt(i)!='('){
				if(top==-1||stack[top]!='(')
					return false;
				top--;
			}
		
		}
		return top==-1;
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		int n = sc.nextInt();
		
		for(int i=0; i<n; i++){
			String s= sc.next();
			if(isValid(s))
				System.out.println(("Yes"));
			else
				System.out.println(("No"));
		}
		
	}

}
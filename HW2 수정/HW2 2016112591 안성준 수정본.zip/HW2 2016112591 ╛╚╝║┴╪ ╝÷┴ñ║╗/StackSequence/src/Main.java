import java.util.Scanner;

class Stack<E>{
	E[] data;
	int top;
	
	Stack(){
		data =(E[]) new Object[1024]; 
		top=-1;
	}
	
	public void push(E v){
		top++;   
		data[top]=v;
	}
	public void pop(){
	
		data[top]=null;
		top--;
	}
	public E top(){
		
		return data[top];
	}
	public boolean empty(){
		
		return top==-1;
	}
	public int size(){
		return top+1;
	}
}


public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		Stack<Integer> stack= new Stack();
		StringBuilder s=new StringBuilder();
		
		int n= sc.nextInt();
		int a=0;
		int max=0;
		for(int i=0;i<n; i++){
			a = sc.nextInt();
			if(a>max){
				for(int k=max+1; k<=a; k++){
					stack.push(k);
					s.append("+ ");
				}
				max=a;
		}else if(stack.top()!=a){
			System.out.println("NO");
			return;
			
		}
		stack.pop();
		s.append("- ");
		
		
			
		}
		System.out.println(s);
	
		
		
			}
			
		
		
	}
